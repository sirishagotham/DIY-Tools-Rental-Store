package com.diytools.rental.service;

import com.diytools.rental.entity.Rental;
import com.diytools.rental.entity.Tool;
import com.diytools.rental.repository.RentalRepository;
import com.diytools.rental.repository.ToolRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RentalService {
    private final RentalRepository rentalRepository;
    private final ToolRepository toolRepository;

    public RentalService(RentalRepository rentalRepository, ToolRepository toolRepository) {
        this.rentalRepository = rentalRepository;
        this.toolRepository = toolRepository;
    }

    public Rental saveRental(Rental rental) {
        Rental saved = rentalRepository.save(rental);
        Tool tool = toolRepository.findById(rental.getToolId()).orElse(null);
        if (tool != null && "ONGOING".equals(rental.getStatus())) {
            tool.setStatus("NOT_AVAILABLE");
            toolRepository.save(tool);
        }
        return saved;
    }

    public List<Rental> getAllRentals() {
        return rentalRepository.findAll();
    }

    public Rental getRentalById(Long id) {
        return rentalRepository.findById(id).orElse(null);
    }

    public Rental updateRental(Long id, Rental updatedRental) {
        Rental rental = rentalRepository.findById(id).orElse(null);
        if (rental != null) {
            rental.setToolId(updatedRental.getToolId());
            rental.setRenterName(updatedRental.getRenterName());
            rental.setRentalDate(updatedRental.getRentalDate());
            rental.setReturnDate(updatedRental.getReturnDate());
            rental.setTotalCost(updatedRental.getTotalCost());
            rental.setStatus(updatedRental.getStatus());

            Rental saved = rentalRepository.save(rental);

            Tool tool = toolRepository.findById(rental.getToolId()).orElse(null);
            if (tool != null) {
                if ("COMPLETED".equals(rental.getStatus())) {
                    tool.setStatus("AVAILABLE"); // Tool returned
                } else if ("ONGOING".equals(rental.getStatus())) {
                    tool.setStatus("NOT_AVAILABLE"); // Tool still in use
                }
                toolRepository.save(tool);
            }
            return saved;
        }
        return null;
    }

    public void deleteRental(Long id) {
        rentalRepository.deleteById(id);
    }
 // ✅ Mark Rental as STARTED
    public Rental markAsStarted(Long id) {
        Rental rental = rentalRepository.findById(id).orElseThrow(() -> new RuntimeException("Rental not found"));
        rental.setStatus("ONGOING");
        rentalRepository.save(rental);

        Tool tool = toolRepository.findById(rental.getToolId())
                .orElseThrow(() -> new RuntimeException("Tool not found"));
        tool.setStatus("NOT_AVAILABLE");
        toolRepository.save(tool);

        return rental;
    }

    // ✅ Mark Rental as RETURNED
    public Rental markAsReturned(Long id) {
        Rental rental = rentalRepository.findById(id).orElseThrow(() -> new RuntimeException("Rental not found"));
        rental.setStatus("COMPLETED");
        rentalRepository.save(rental);

        Tool tool = toolRepository.findById(rental.getToolId())
                .orElseThrow(() -> new RuntimeException("Tool not found"));
        tool.setStatus("AVAILABLE");
        toolRepository.save(tool);

        return rental;
    }
}

