package com.diytools.rental.controller;

import com.diytools.rental.entity.User;
import com.diytools.rental.service.UserService;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // ✅ REGISTER ENDPOINT
    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return userService.register(user);
    }

    // ✅ LOGIN ENDPOINT
    @PostMapping("/login")
    public String login(@RequestBody User user) {
        boolean isValid = userService.validateLogin(user.getUsername(), user.getPassword());
        return isValid ? "Login successful" : "Invalid username or password";
    }
 // ✅ GET ALL USERS
    @GetMapping("/all")
    public java.util.List<User> getAllUsers() {
        return userService.getAllUsers();
    }

}
