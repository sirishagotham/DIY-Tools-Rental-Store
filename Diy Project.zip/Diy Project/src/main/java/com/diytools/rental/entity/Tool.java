package com.diytools.rental.entity;

import jakarta.persistence.*;

@Entity
public class Tool {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String description;

    private double dailyRate;

    // New status column for Tool: "AVAILABLE", "NOT_AVAILABLE"
    private String status;

    // Getters and Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }  
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }  
    public void setDescription(String description) {
        this.description = description;
    }
    public double getDailyRate() {
        return dailyRate;
    }  
    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }
    public String getStatus() {
        return status;
    }  
    public void setStatus(String status) {
        this.status = status;
    }
}
