package com.diytools.rental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiyToolsRentalApplication {
    public static void main(String[] args) {
        SpringApplication.run(DiyToolsRentalApplication.class, args);
    }
}
