package com.diytools.rental.service;

import com.diytools.rental.entity.Tool;
import com.diytools.rental.repository.ToolRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ToolService {
    private final ToolRepository toolRepository;

    public ToolService(ToolRepository toolRepository) {
        this.toolRepository = toolRepository;
    }

    public Tool saveTool(Tool tool) {
        return toolRepository.save(tool);
    }

    public List<Tool> getAllTools() {
        return toolRepository.findAll();
    }

    public Tool getToolById(Long id) {
        return toolRepository.findById(id).orElse(null);
    }

    public Tool updateTool(Long id, Tool updatedTool) {
        Tool tool = toolRepository.findById(id).orElse(null);
        if (tool != null) {
            tool.setName(updatedTool.getName());
            tool.setDescription(updatedTool.getDescription());
            tool.setDailyRate(updatedTool.getDailyRate());
            tool.setStatus(updatedTool.getStatus());
            return toolRepository.save(tool);
        }
        return null;
    }

    public void deleteTool(Long id) {
        toolRepository.deleteById(id);
    }
}
