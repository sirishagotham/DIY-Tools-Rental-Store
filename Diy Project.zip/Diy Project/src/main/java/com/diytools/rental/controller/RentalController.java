package com.diytools.rental.controller;

import com.diytools.rental.entity.Rental;
import com.diytools.rental.service.RentalService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/rentals")
public class RentalController {
    private final RentalService rentalService;

    public RentalController(RentalService rentalService) {
        this.rentalService = rentalService;
    }

    @PostMapping
    public Rental createRental(@RequestBody Rental rental) {
        return rentalService.saveRental(rental);
    }

    @GetMapping
    public List<Rental> getAllRentals() {
        return rentalService.getAllRentals();
    }

    @GetMapping("/{id}")
    public Rental getRentalById(@PathVariable Long id) {
        return rentalService.getRentalById(id);
    }

    @PutMapping("/{id}")
    public Rental updateRental(@PathVariable Long id, @RequestBody Rental rental) {
        return rentalService.updateRental(id, rental);
    }

    @DeleteMapping("/{id}")
    public void deleteRental(@PathVariable Long id) {
        rentalService.deleteRental(id);
    }
    // ✅ Mark as Started (ONGOING) -> Tool becomes NOT_AVAILABLE
    @PostMapping("/{id}/start")
    public Rental markRentalAsStarted(@PathVariable Long id) {
        return rentalService.markAsStarted(id);
    }

    // ✅ Mark as Returned (COMPLETED) -> Tool becomes AVAILABLE
    @PostMapping("/{id}/return")
    public Rental markRentalAsReturned(@PathVariable Long id) {
        return rentalService.markAsReturned(id);
    }
}

